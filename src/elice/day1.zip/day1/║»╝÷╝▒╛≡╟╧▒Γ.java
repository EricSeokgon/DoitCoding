package elice.day1;

import elice.코딩별;

public class 변수선언하기 {

    public static void main(String[] args) {

        String 이름 = "나래";
        int 나이 = 25;
        double 키 = 151.3;
        코딩별.출력(이름 + "  " + 나이 + "살 " + 키 + "cm");

        이름 = "서준";
        나이 = 30;
        키 = 183.5;
        코딩별.출력(이름 + "  " + 나이 + "살 " + 키 + "cm");
    }
}